@extends( 'layouts/admin_layout' )
@section( 'content' )

<style>
    .nowraptd {
        white-space: nowrap;
    }
    .dn{display: none;}
</style>


<div class="container-fluid pagecontentbody">
    <div class="pagebody removebg-color">
        <div class="row">
            <div class="col-12">
                <div class="pageheader" id="menu-margin">
                    <h4 class="mb-0">
                        Incentive Committee Form
                        <!--<a href="dashboard.html" class="btn btn-outline-danger btn-sm backbtn float-end rounded-pill"><span class="icons icon-arrow-left"></span>Back to Dashboard</a>-->
                        <!-- <a title=" Incentive Committee Details ExportToExcel" class="btn btn-sm btn-success float-end" onclick="ExportToExcel('xlsx')">
                            <i class="fa fa-file-excel"></i>Export to Excel
                        </a> -->
                    </h4>
                </div>
            </div>

            <div class="col-12">
                <div class="bhoechie-tab-container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bhoechie-tab">
                            <div class="bhoechie-tab-content active">
                                <div class="form-scroll">
                                    <div class="nano-content">
                                        <div class="row">
                                            <h4 class="mb-0"> <!-- id="print" onclick="printContent('print_table')" -->
                                                <a title="Print" class="btn btn-warning float-end" data-print="modal" onclick="PrintDoc()"><i class="icons icon-printer"></i> Print</a>
                                            </h4>
                                            <form action="{{url('admin/information/create_incentive')}}" class="needs-validation" novalidate method="post" autocomplete="off">
                                                @csrf
                                                <div class="col-12">
                                                    <fieldset>
                                                        <div class="row">
                                                            <?php if (!empty($district_id)) { ?>
                                                                <div class="col-md-4">
                                                                    <div class="form-group">
                                                                        <label class="placeholder">Type <span class="text-danger">*</span></label>
                                                                        <div class="form-control">
                                                                            <div class=" form-check-inline">
                                                                                <input required class="form-check-input" type="radio" name="identified_the_department" id="department_yes" value="1">
                                                                                <label class="form-check-label mb-0" for="inlineCheckbox1">District</label>
                                                                            </div>
                                                                            <div class=" form-check-inline">
                                                                                <input required class="form-check-input" type="radio" name="identified_the_department" id="department_no" value="2">
                                                                                <label class="form-check-label mb-0" for="inlineCheckbox2">Tehsil</label>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4" id="district_name_selected" style="display: none;">
                                                                    <div class="form-group mb-3">
                                                                        <label class="placeholder">District Name <span class="text-danger">*</span></label>
                                                                        <select name="district_name" id="district_name" class="form-control form-select" required>
                                                                            @foreach($districts as $key=>$district)
                                                                            <option {{$district->id == 23 ? 'selected' : ''}} value="{{ $district->id }}" data-badge="">{{$district->city}}</option>
                                                                            @endforeach
                                                                        </select>
                                                                    </div>
                                                                    @error('district_name')
                                                                    <div class="text-danger">{{ $message }}</div>
                                                                    @enderror
                                                                </div>
                                                                <div class="col-md-4" id="tehsil_name_selected" style="display: none;">
                                                                    <div class="form-group mb-3">
                                                                        <label class="placeholder">Tehsil Name <span class="text-danger">*</span></label>
                                                                        <select name="tehsil_name" id="tehsil_name" class="form-control form-select" required>
                                                                            <option selected="" disabled="" value="">Select Tehsil</option>
                                                                            @foreach($tehsils as $key=>$tehsil)
                                                                            <option {{$tehsil->id == 561 ? 'selected' : ''}} value="{{ $tehsil->id }}" data-badge="">{{$tehsil->Tehsil_Name}}</option>
                                                                            @endforeach
                                                                        </select>
                                                                    </div>
                                                                    @error('tehsil_name')
                                                                    <div class="text-danger">{{ $message }}</div>
                                                                    @enderror
                                                                </div>
                                                            <?php } ?>
                                                            <div class="col-md-4">
                                                                <div class="form-group mb-3">
                                                                    <label class="placeholder">Date of Committee Formation <span class="text-danger">*</span></label>
                                                                    <input type="date" max="<?php echo date("Y-m-d"); ?>" name="date_of_committee_formation" id="date_of_committee_formation" class="form-control" data-language="en" required>
                                                                </div>
                                                                @error('date_of_committee_formation')
                                                                <div class="text-danger">{{ $message }}</div>
                                                                @enderror
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-group mb-3">
                                                                    <label class="placeholder">Date of Registration and Renewal of The Committee <span class="text-danger">*</span></label>
                                                                    <input type="date" name="date_of_registration_renewal_committee" id="date_of_registration_renewal_committee" class="form-control" data-language="en" required>
                                                                </div>
                                                                @error('date_of_registration_renewal_committee')
                                                                <div class="text-danger">{{ $message }}</div>
                                                                @enderror
                                                            </div>
                                                        </div>
                                                    </fieldset>
                                                </div>
                                                <div class="col-12">
                                                    <fieldset>
                                                        <legend>Bank Details</legend>
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <div class="form-group mb-3">
                                                                    <label class="placeholder">Bank Name <span class="text-danger">*</span></label>
                                                                    <input type="text" onkeypress="return ((event.charCode >= 65 && event.charCode <= 90) || (event.charCode >= 97 && event.charCode <= 122) || (event.charCode == 32))" name="bank_name" id="bank_name" class="form-control" required>
                                                                </div>
                                                                @error('bank_name')
                                                                <div class="text-danger">{{ $message }}</div>
                                                                @enderror
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="form-group mb-3">
                                                                    <label class="placeholder">A/c Number <span class="text-danger">*</span></label>
                                                                    <input type="number" name="ac_number" min="999999999" max="100000000000000000" id="ac_number" class="form-control" required>
                                                                </div>
                                                                @error('ac_number')
                                                                <div class="text-danger">{{ $message }}</div>
                                                                @enderror
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="form-group mb-3">
                                                                    <label class="placeholder">IFSC Code <span class="text-danger">*</span></label>
                                                                    <input type="text" name="ifsc_code" maxlength="14" id="ifsc_code" pattern="^[A-Za-z]{4}0[A-Z0-9a-z]{6}$" class="form-control" required>
                                                                </div>
                                                                @error('ifsc_code')
                                                                <div class="text-danger">{{ $message }}</div>
                                                                @enderror
                                                            </div>
                                                        </div>
                                                        <div class="bhoechie-footer">
                                                            <div class="row justify-content-center">
                                                                <div class="col-md-2 d-grid">
                                                                    <button id="reset" type="reset" class="btn btn-outline-info rounded-pill">Reset</button>
                                                                </div>
                                                                <div class="col-md-2 d-grid">
                                                                    <button type="submit" class="btn btn-outline-danger rounded-pill">Save</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <input type="hidden" name="division_id" id="division_id" value="{{!empty($division_id) ? $division_id : 'null' }}">
                                                    </fieldset>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="col-12">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="table-responsive" id="prodiv">
                                                        <table style="width: 100%;" class="dn">
                                                            <tr>
                                                                <td align="center" style="position: relative; border: 0; padding-bottom: 5px;">
                                                                    <div style="border-bottom: 0px solid #000; padding-bottom: 2vw;">
                                                                        <!-- <img src="{{ url('/public/onlineAdmission') }}/images/logo.png" style="position: absolute; width: 70px; top: 5px; left: 0;"/> -->
                                                                        <!-- <img src="images/logo.png" style="position: absolute; width: 70px; top: 5px; left: 0;"/> -->
                                                                        <div style="font-size: 18px; font-weight: bold;">
                                                                            <!-- Department of Sports -->
                                                                            Khel Sathi Portal
                                                                        </div>
                                                                        <div style="font-size: 14px; font-weight: bold;">
                                                                            Government of Uttar Pradesh
                                                                        </div>
                                                                        <div style="font-size: 18px; font-weight: bold;">
                                                                            Sport College online application form
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                        <table class="table table-bordred table-hover bg-white datatable mb-3" id="dataTable">
                                                            <thead>
                                                                <tr>
                                                                    <th rowspan="2">S.No.</th>
                                                                    <?php if ($admin_id == 10) { ?>
                                                                        <th rowspan="2">Division Name</th>
                                                                        <th colspan="1" class="text-center">Date of Committee Formation</th>
                                                                        <th colspan="1" class="text-center">Date of Registration and Renewal of The Committee</th>
                                                                        <th colspan="1" class="text-center">Full Details of Bank Account</th>
                                                                    <?php } ?>
                                                                    <?php if ($admin_id == 9) { ?>
                                                                        <th rowspan="2">District Name</th>
                                                                        <th rowspan="2">Tehsil Name</th>
                                                                        <th colspan="2" class="text-center">Date of Committee Formation</th>
                                                                        <th colspan="2" class="text-center">Date of Registration and Renewal of The Committee</th>
                                                                        <th colspan="2" class="text-center">Full Details of Bank Account</th>
                                                                    <?php } ?>
                                                                </tr>
                                                                <?php if ($admin_id == 10) { ?>
                                                                    <tr>
                                                                        <th>Divisional Level</th>
                                                                        <th>Divisional Level</th>
                                                                        <th>Divisional Level</th>
                                                                    </tr>
                                                                <?php } ?>
                                                                <?php if ($admin_id == 9) { ?>
                                                                    <tr>
                                                                        <th>District Level</th>
                                                                        <th>Tehsil Level</th>
                                                                        <th>District Level</th>
                                                                        <th>Tehsil Level</th>
                                                                        <th>District Level</th>
                                                                        <th>Tehsil Level</th>
                                                                    <?php } ?>
                                                                    </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php
                                                                //print_r($incentiveCommittee); die;
                                                                // if(isset($incentiveCommittee[0]->division_id == null)){
                                                                // }
                                                                ?>
                                                                @foreach($incentiveCommittee as $key=>$item)
                                                                <tr>
                                                                    <td>{{ $key+1 }}</td>
                                                                    <?php if ($item->status == 0) { ?>
                                                                        <td>{{!empty(divisionName($item->division_id)) ? divisionName($item->division_id) : '-' }}</td>
                                                                        <td class="nowraptd">{{ !empty(date('d-m-Y', strtotime($item->date_of_committee_formation ))) ? date('d-m-Y', strtotime($item->date_of_committee_formation )): '-'}}</td>
                                                                        <td class="nowraptd">{{ date('d-m-Y', strtotime($item->date_of_registration_renewal_committee)) }}</td>
                                                                        <td>{{isset($item->bank_name) ? $item->bank_name : '-' }}</td>
                                                                    <?php } ?>
                                                                    <?php //1 District
                                                                    if ($item->status == 1) { ?>
                                                                        <td>{{!empty(districtName($item->district_id)) ? districtName($item->district_id) : '-' }} </td>
                                                                        <td>-</td>
                                                                        <td class="nowraptd">{{ !empty(date('d-m-Y', strtotime($item->date_of_committee_formation ))) ? date('d-m-Y', strtotime($item->date_of_committee_formation )): '-'}}</td>
                                                                        <td>-</td>
                                                                        <td class="nowraptd">{{ date('d-m-Y', strtotime($item->date_of_registration_renewal_committee)) }}</td>
                                                                        <td>-</td>
                                                                        <td>{{isset($item->bank_name) ? $item->bank_name : '-' }}</td>
                                                                        <td>-</td>
                                                                    <?php } ?>
                                                                    <?php
                                                                    //2 tehsil name
                                                                    if ($item->status == 2) { ?>
                                                                        <td>-</td>
                                                                        <td>{{!empty(tehsiltName($item->tehsil_id)) ? tehsiltName($item->tehsil_id) : '-' }}</td>
                                                                        <td>-</td>
                                                                        <td class="nowraptd">{{ date('d-m-Y', strtotime($item->date_of_committee_formation ))}}</td>
                                                                        <td>{{isset($item->division_id) ? $item->division_id : '-' }}</td>
                                                                        <td class="nowraptd">{{ date('d-m-Y', strtotime($item->date_of_registration_renewal_committee)) }}</td>
                                                                        <td>-</td>
                                                                        <td>-</td>
                                                                    <?php } ?>
                                                                    <!-- <td>{{ $item->ac_number}}</td>
                                                                    <td>{{ $item->ifsc_code}}</td> -->
                                                                </tr>
                                                                @endforeach
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

@endsection

@push( 'custom-scripts' )

<script>
    function PrintDoc() {
        $('#dataTable').DataTable().destroy();
        var toPrint = document.getElementById('prodiv');

        var popupWin = window.open('', '_blank', 'left=100,top=100,width=1100,height=600,tollbar=0,scrollbars=1,status=0,resizable=1');

        popupWin.document.open();

        popupWin.document.write('<html><title>::Preview::</title><head><style>body{font-family:Arial} .noprint{display: none;} table{width:100%; border-collapse:collapse;} .table tr th, .table tr td{border:1px solid #000; padding:3px 5px; font-size: 12px;} .table > thead > tr > th{background-color: #eee;}</style></head><body onload="window.print()">')

        popupWin.document.write(toPrint.innerHTML);

        popupWin.document.write('</body></html>');

        popupWin.document.close();

        $('#dataTable').DataTable();

    }
</script>

<script type="text/javascript">
    $(function() {
        var table = $('.yajra-datatable').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{ route('projectlist') }}",
            columns: [{
                data: 'DT_RowIndex',
                name: 'DT_RowIndex'
            }, {
                data: 'fullname',
                name: 'fullname'
            }, {
                data: 'project_id',
                name: 'project_id'
            }, {
                data: 'project_name',
                name: 'project_name'
            }, {
                data: 'application_date',
                name: 'application_date'
            }, {
                data: 'current_status',
                name: 'current_status',
                orderable: false,
                searchable: false
            }, {
                data: 'view',
                name: 'view',
                orderable: false,
                searchable: false
            }, ]
        });
    });
</script>
<script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
<script>
    function ExportToExcel(type, fn, dl) {
        var elt = document.getElementById('dataTable');
        var wb = XLSX.utils.table_to_book(elt, {
            sheet: "sheet1"
        });
        return dl ?
            XLSX.write(wb, {
                bookType: type,
                bookSST: true,
                type: 'base64'
            }) :
            XLSX.writeFile(wb, fn || ('Incentive Committee List.' + (type || 'xlsx')));
    }
</script>
<script type="text/javascript">
    $('input[name="identified_the_department"]').click(function() {
        var identified_the_department = $(this).val();
        if (identified_the_department == 1) {
            $('#district_name_selected').show();
            $('#tehsil_name_selected').hide();
            $("#district_name").prop('required', true);
            $("#tehsil_name").prop('required', false);
        } else if (identified_the_department == 2) {
            $('#tehsil_name_selected').show();
            $('#district_name_selected').hide();
            $("#district_name").prop('required', false);
            $("#tehsil_name").prop('required', true);
            //$("#um_land_remarks").prop('required', false);
        }
    });
</script>

<script type="text/javascript">
    $(document).ready(function() {
        $('#reset').click(function() {
            $('#district_name_selected').hide();

        });
    });


    //     $(document).ready(function() {
    //     var table = $('#dataTable').DataTable( {
    //         lengthChange: false,
    //         buttons: [ 'copy', 'excel', 'pdf', 'colvis' ]
    //     } );

    //     table.buttons().container()
    //         .appendTo( '#example_wrapper .col-sm-6:eq(0)' );
    // } );

    // $(document).ready(function() {
    //     $('#dataTable').DataTable( {
    //         dom: 'Bfrtip',
    //         buttons: [
    //             'print'
    //         ]
    //     } );
    // } );
</script>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">
    //=============================
    function printContent(el) {
        alert('1');
        var restorepage = document.body.innerHTML;
        var printcontent = document.getElementById(el).innerHTML;
        document.body.innerHTML = printcontent;
        window.print();
        document.body.innerHTML = restorepage;
    }
</script> -->
@endpush