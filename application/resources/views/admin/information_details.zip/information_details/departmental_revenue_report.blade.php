@extends( 'layouts/admin_layout' )
@section( 'content' )


<div class="row">
            <div class="col-12">
                <div class="pageheader" id="menu-margin">
                    <h4 class="mb-0">
विभागीय राजस्व प्रपत्र                    </h4>
                </div>
            </div>
            <div class="col-12">
                <div class="table-responsive">
                                                        <table  class="table table-bordred table-hover bg-white datatable mb-3" id="dataTable">
                                                                <thead>
                                                                    <tr>
                                                                        <th colspan="31" class="text-center">कार्यालय का नाम</th>
                                                                    </tr>
                                                                    <tr>
                                                                        <th colspan="13" class="text-center">विभागीय राजस्व प्राप्तियों का विवरण</th>
                                                                        <th colspan="7" class="text-center">माह का नाम                                       - </th>
                                                                        <th colspan="5" class="text-center"><strong> वर्ष</strong> - </th>
                                                                        <th colspan="6" class="text-center">(धनराशि रू. में). -</th>
                                                                    </tr>
                                                                    <tr>
                                                                        <th colspan="2" class="text-center">विवरण</th>
                                                                        <th colspan="4" class="text-center"><table border="0" cellspacing="0" cellpadding="0" width="1016">
                                                                          <tr>
                                                                            <td width="126" valign="top"><p align="center">प्रशिक्षण मद से आय</p></td>
                                                                          </tr>
                                                                        </table></th>
                                                                        <th colspan="6" class="text-center">आरक्षण  मद से आय</th>
                                                                        <th colspan="4" class="text-center">तरणताल  मद से आय</th>
                                                                        <th colspan="4" class="text-center">छात्रावास  मद से आय</th>
                                                                        <th colspan="10" class="text-center">अन्य  प्राप्तियों के मद से आय</th>
                                                                        <th rowspan="2" class="text-center">माह में प्राप्त कुल राजस्व</th>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>जनपद/संस्था  का नाम</th>
                                                                        <th>जिला/संस्था का नाम</th>
                                                                        <th>तहसील का नाम</th>
                                                                        <th>खेल का नाम</th>
                                                                        <th>प्रशिक्षुओं की संख्या</th>
                                                                        <th>निर्धारित शुल्क</th>
                                                                        <th>कुल आय</th>
                                                                        <th>विभागीय रसीद संख्या</th>
                                                                        <th>खेल के मैदान/मैदान से किराया</th>
                                                                        <th>बहुउद्देशीय हॉल से किराया</th>
                                                                        <th>रूम बुकिंग से किराया</th>
                                                                        <th>स्टेडियम बुकिंग से किराया</th>
                                                                        <th>कुल आय</th>
                                                                        <th>विभागीय रसीद संख्या एवं दिनांक</th>
                                                                        <th>प्रशिक्षुओं की संख्या</th>
                                                                        <th>निर्धारित शुल्क</th>
                                                                        <th>कुल आय</th>
                                                                        <th>विभागीय रसीद संख्या एवं दिनांक</th>
                                                                        <th>छात्र की संख्या</th>
                                                                        <th>निर्धारित शुल्क</th>
                                                                        <th>कुल आय</th>
                                                                        <th>विभागीय रसीद संख्या एवं दिनांक</th>
                                                                        <th>शौकिया खिलाड़ियों की संख्या</th>
                                                                        <th>निश्चित शुल्क/खिलाड़ी</th>
                                                                        <th>कुल आय</th>
                                                                        <th>विभागीय रसीद संख्या एवं दिनांक</th>
                                                                        <th>कार/मोटरसाइकिल/साइकिल स्टैंड से आय</th>
                                                                        <th>अनुपयोगी मोर्चों की नीलामी से प्राप्त आय</th>
                                                                        <th>फॉर्म की बिक्री से आय</th>
                                                                        <th>विभाग की आय के अन्य स्रोतों से आय</th>
                                                                        <th>कुल आय</th>
                                                                        <th>विभागीय रसीद संख्या एवं दिनांक</th>
                                                                    </tr>
                                                                  
                                                                    <tr>
                                                                    
                                                                   
                                                                        <th class="text-center">1</th>
                                                                    
                                                                        <th class="text-center">2</th>
                                                                        <th class="text-center">3</th>
                                                                        <th class="text-center">4</th>
                                                                        <th class="text-center">5</th>
                                                                        <th class="text-center">6</th>
                                                                        <th class="text-center">7</th>
                                                                        <th class="text-center">8</th>
                                                                        <th class="text-center">9</th>
                                                                        <th class="text-center">10</th>
                                                                        <th class="text-center">11</th>
                                                                        <th class="text-center">12</th>
                                                                        <th class="text-center">13</th>
                                                                        <th class="text-center">14</th>
                                                                        <th class="text-center">15</th>
                                                                        <th class="text-center">16</th>
                                                                        <th class="text-center">17</th>
                                                                        <th class="text-center">18</th>
                                                                        <th class="text-center">19</th>
                                                                        <th class="text-center">20</th>
                                                                        <th class="text-center">21</th>
                                                                        <th class="text-center">22</th>
                                                                        <th class="text-center">23</th>
                                                                        <th class="text-center">24</th>
                                                                        <th class="text-center">25</th>
                                                                        <th class="text-center">26</th>
                                                                        <th class="text-center">27</th>
                                                                        <th class="text-center">28</th>
                                                                        <th class="text-center">29</th>
                                                                        <th class="text-center">30</th>
                                                                        <th class="text-center">31</th>
                                                                    </tr>
                                                                   
                                                                </thead>
                                                                <tbody>
                                                                @foreach($departmentalInformation as $key=>$item)
                                                                    <tr>
                                                                    <?php if($item->status == 0) { ?>
                                                                        <td>{{!empty(divisionName($item->division_id)) ? divisionName($item->division_id) : '-' }}</td>
                                                                        <td>-</td>
                                                                        <td>-</td>
                                                                        <td>{{!empty($item->name_of_sport) ? $item->name_of_sport : '-' }}</td>
                                                                        <?php } ?>
                                                                        <?php if($item->status == 1) {?>
                                                                        <td>-</td>
                                                                        <td>{{!empty(districtName($item->district_id)) ? districtName($item->district_id) : '-' }}</td>
                                                                        <td>-</td>
                                                                        <td>{{!empty($item->name_of_sport) ? $item->name_of_sport : '-' }}</td>
                                                                        <?php } ?>
                                                                        <?php if($item->status == 2) {?>
                                                                            
                                                                        <td>-</td>
                                                                        <td>-</td>
                                                                          
                                                                        <td>{{!empty(tehsiltName($item->tehsil_id)) ? tehsiltName($item->tehsil_id) : '-' }}</td>
                                                                        <td>{{!empty($item->name_of_sport) ? $item->name_of_sport : '-' }}</td>
                                                                     
                                                                        <?php } ?>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                        <td>&nbsp;</td>
                                                                    </tr>                                                             
                                                                   
                                                                    @endforeach                                                         
                                                                   
                                                                 
                                                                   
                                                                    <tr>
                                                                        <td><strong>योग</strong></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                        <td></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td colspan="30"><strong>माह  में राजस्व प्राप्तियां</strong></td>
                                                                        <td></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td colspan="30"><strong>गत  माह की राजस्व प्राप्तियां</strong></td>
                                                                        <td></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td colspan="30"><strong>प्रगामी  राजस्व प्राप्तियां</strong></td>
                                                                        <td></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td colspan="30"><strong>गत  वित्तीय वर्ष में इसी माह तक राजस्व प्राप्तियां</strong></td>
                                                                        <td></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td colspan="30"><strong>राजस्व  प्राप्तियां में प्रतिशत वृद्धि अथवा कमी</strong></td>
                                                                        <td></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td colspan="31"><strong>प्रमाणित  किया जाता है उपरोक्त सभी सूचनाएं मेरी जानकारी में सही हैं तथा प्राप्त राजस्व  प्राप्तियों को विभागीय लेखाशीर्षक में जमा करा दिया गया है, गलत सूचना पाये जाने  पर वसूली हेतु उत्तरदायी रहेंगे।</strong></td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
  </div>
            </div>



@endsection

@push( 'custom-scripts' )
<script type="text/javascript">
    $(function() {
        var table = $('.yajra-datatable').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{ route('projectlist') }}",
            columns: [{
                data: 'DT_RowIndex',
                name: 'DT_RowIndex'
            }, {
                data: 'fullname',
                name: 'fullname'
            }, {
                data: 'project_id',
                name: 'project_id'
            }, {
                data: 'project_name',
                name: 'project_name'
            }, {
                data: 'application_date',
                name: 'application_date'
            }, {
                data: 'current_status',
                name: 'current_status',
                orderable: false,
                searchable: false
            }, {
                data: 'view',
                name: 'view',
                orderable: false,
                searchable: false
            }, ]
        });
    });
</script>
<script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
<script>
    function ExportToExcel(type, fn, dl) {
        var elt = document.getElementById('dataTable');
        var wb = XLSX.utils.table_to_book(elt, {
            sheet: "sheet1"
        });
        return dl ?
            XLSX.write(wb, {
                bookType: type,
                bookSST: true,
                type: 'base64'
            }) :
            XLSX.writeFile(wb, fn || ('Sports Infrastructure List.' + (type || 'xlsx')));
    }
</script>
    @endpush