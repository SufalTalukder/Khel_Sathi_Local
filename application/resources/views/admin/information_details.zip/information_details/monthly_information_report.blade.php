@extends( 'layouts/admin_layout' )
@section( 'content' )
<style>
     .dn{display: none;}
</style>

<div class="container-fluid pagecontentbody">
    <div class="pagebody removebg-color">
        <div class="row">
            <div class="col-12">
                <div class="pageheader" id="menu-margin">
                    <h4 class="mb-0">
                        Monthly Information Form
                        <!-- <a title=" Monthly Information Form Details ExportToExcel" class="btn btn-sm btn-success float-end" onclick="ExportToExcel('xlsx')">
                            <i class="fa fa-file-excel"></i>Export to Excel
                        </a> -->
                        <a title="Print" class="btn btn-warning btn-sm float-end" data-print="modal" onclick="PrintDoc()"><i class="icons icon-printer"></i> Print</a>
                        
                    </h4>

                    
                </div>
            </div>
            <div class="col-12">
                <div class="bhoechie-tab-container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bhoechie-tab">
                            <div class="bhoechie-tab-content active">
                                <div class="form-scroll">
                                    <div class="nano-content">
                                        <div class="row">
                                            
                                         
                                        </div>

                                        <div class="col-12">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="table-responsive" id="prodiv">
                                                        <table style="width: 100%;" class="dn">
                                                            <tr>
                                                                <td align="center" style="position: relative; border: 0; padding-bottom: 5px;">
                                                                    <div style="border-bottom: 0px solid #000; padding-bottom: 2vw;">
                                                                        <!-- <img src="{{ url('/public/onlineAdmission') }}/images/logo.png" style="position: absolute; width: 70px; top: 5px; left: 0;"/> -->
                                                                        <!-- <img src="images/logo.png" style="position: absolute; width: 70px; top: 5px; left: 0;"/> -->
                                                                        <div style="font-size: 18px; font-weight: bold;">
                                                                            <!-- Department of Sports -->
                                                                            Khel Sathi Portal
                                                                        </div>
                                                                        <div style="font-size: 14px; font-weight: bold;">
                                                                            Government of Uttar Pradesh
                                                                        </div>
                                                                        <div style="font-size: 18px; font-weight: bold;">
                                                                            Sport College online application form
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    <table  class="table table-bordred table-hover bg-white datatable mb-3" id="dataTable">
                                                            <thead>
                                                                <tr>
                                                                    <th>S.No.</th>                                                                  
                                                                    <th>Division Name</th>                                                           
                                                                    <th>District Name</th>
                                                                    <th>Tehsil Name</th>                                                                   
                                                                    <th>Opening Balance of Financial Year</th>
                                                                    <th>Amount Received in Current Month</th>
                                                                    <th>Amount Spent in Current Month</th>
                                                                    <th>Total Balance Deposited Till Current Month</th>
                                                                    <th>Total Amount Received Till Current Month</th>
                                                                    <th>Total Amount Received Till The Same Month Last Year</th>
                                                                    <th>Increase</th>
                                                                    <th>Decrease</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                            @foreach($monthlyInformation as $key=>$item)
                                                                <tr>
                                                                    <td>{{$key+1}}</td>
                                                                   
                                                                    <?php if($item->status == 0 ){ ?>
                                                                    <td>{{!empty(divisionName($item->division_id)) ? divisionName($item->division_id) : '-' }}</td>
                                                                    <td>-</td>
                                                                    <td>-</td>
                                                                    <?php } ?> 
                                                                    <?php if($item->status == 1 ){ ?>          
                                                                    <td>-</td>                                                                                                   
                                                                    <td>{{!empty(districtName($item->district_id)) ? districtName($item->district_id) : '-' }} </td> 
                                                                    <td>-</td>
                                                                    <?php } ?>
                                                                    <?php if($item->status == 2 ){ ?>
                                                                        <td>-</td>
                                                                        <td>-</td>
                                                                    <td>{{!empty(tehsiltName($item->tehsil_id)) ? tehsiltName($item->tehsil_id) : '-' }}</td>
                                                                                                                                      
                                                                    <?php } ?>
                                                                    <td>{{isset($item->opening_balance_of_financial) ? $item->opening_balance_of_financial : '-' }}</td> 
                                                                    <td>{{isset($item->amount_received) ? $item->amount_received : '-' }}</td> 
                                                                    <td>{{isset($item->amount_spent) ? $item->amount_spent : '-' }}</td> 
                                                                    <td>{{isset($item->total_balance_deposited_current_month) ? $item->total_balance_deposited_current_month : '-' }}</td> 
                                                                    <td>{{isset($item->total_amount_received_current_month) ? $item->total_amount_received_current_month : '-' }}</td> 
                                                                    <td>{{isset($item->total_amount_received_lastyear) ? $item->total_amount_received_lastyear : '-' }}</td> 
                                                                    
                                                                    <td>{{isset($item->increase) ? $item->increase : '-' }}</td> 
                                                                    <td>{{isset($item->decrease) ? $item->decrease : '-' }}</td> 

                                                                    
                                                                </tr>                                                             
                                                            @endforeach  
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

@endsection

@push( 'custom-scripts' )

<script>
    function PrintDoc() {
        $('#dataTable').DataTable().destroy();
        var toPrint = document.getElementById('prodiv');

        var popupWin = window.open('', '_blank', 'left=100,top=100,width=1100,height=600,tollbar=0,scrollbars=1,status=0,resizable=1');

        popupWin.document.open();

        popupWin.document.write('<html><title>::Preview::</title><head><style>body{font-family:Arial} .noprint{display: none;} table{width:100%; border-collapse:collapse;} .table tr th, .table tr td{border:1px solid #000; padding:3px 5px; font-size: 12px;} .table > thead > tr > th{background-color: #eee;}</style></head><body onload="window.print()">')

        popupWin.document.write(toPrint.innerHTML);

        popupWin.document.write('</body></html>');

        popupWin.document.close();

        $('#dataTable').DataTable();

    }
</script>
<script type="text/javascript">
    $(function() {
        var table = $('.yajra-datatable').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{ route('projectlist') }}",
            columns: [{
                data: 'DT_RowIndex',
                name: 'DT_RowIndex'
            }, {
                data: 'fullname',
                name: 'fullname'
            }, {
                data: 'project_id',
                name: 'project_id'
            }, {
                data: 'project_name',
                name: 'project_name'
            }, {
                data: 'application_date',
                name: 'application_date'
            }, {
                data: 'current_status',
                name: 'current_status',
                orderable: false,
                searchable: false
            }, {
                data: 'view',
                name: 'view',
                orderable: false,
                searchable: false
            }, ]
        });
    });
</script>

<script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
<script>
    function ExportToExcel(type, fn, dl) {
        var elt = document.getElementById('dataTable');
        var wb = XLSX.utils.table_to_book(elt, {
            sheet: "sheet1"
        });
        return dl ?
            XLSX.write(wb, {
                bookType: type,
                bookSST: true,
                type: 'base64'
            }) :
            XLSX.writeFile(wb, fn || ('Monthly Information List.' + (type || 'xlsx')));
    }
</script>
<script type="text/javascript">
    $('input[name="identified_the_department"]').click(function() {
    var identified_the_department = $(this).val();
    if (identified_the_department == 1) {
    $('#district_name_selected').show();
    $('#tehsil_name_selected').hide();
    $("#district_name").prop('required', true);
    $("#tehsil_name").prop('required', false);
    } else if (identified_the_department == 2) {
    $('#tehsil_name_selected').show();
    $('#district_name_selected').hide();
    $("#district_name").prop('required', false);
    $("#tehsil_name").prop('required', true);
    //$("#um_land_remarks").prop('required', false);
    }
    });
</script>
<script type="text/javascript">
$(document).ready(function () {
    $('#reset').click(function () {
        $('#district_name_selected').hide();

    });
});
</script>
@endpush