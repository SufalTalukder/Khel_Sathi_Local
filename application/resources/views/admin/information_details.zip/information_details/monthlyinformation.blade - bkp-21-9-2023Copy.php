@extends( 'layouts/admin_layout' )
@section( 'content' )
<style>
     .dn{display: none;}
</style>

<div class="container-fluid pagecontentbody">
    <div class="pagebody removebg-color">
        <div class="row">
            <div class="col-12">
                <div class="pageheader" id="menu-margin">
                <h4 class="mb-0">
                        Monthly Information Form
                        <a title="Print" class="btn btn-warning btn-sm float-end" data-print="modal" onclick="PrintDoc()"><i class="icons icon-printer"></i> Print</a>
                    </h4>
                   
                </div>
            </div>
            <div class="col-12">
                <div class="bhoechie-tab-container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bhoechie-tab">
                            <div class="bhoechie-tab-content active">
                                <div class="form-scroll">
                                    <div class="nano-content">
                                        <div class="row">
                                            <form  <?php if($admin_id == 1){ ?> style="display:none" <?php } ?> action="{{url('admin/information/create_monthly_information')}}" class="needs-validation" novalidate method="post" autocomplete="off">
                                                @csrf
                                                <div class="col-12">
                                                    <fieldset>
                                                       
                                                        <div class="row">
                                                        <?php if(!empty($district_id_monthly)){ ?>
                                                        
                                                        <div class="col-md-4">
                                                                <div class="form-group">   
                                                                <label class="placeholder">Type <span class="text-danger">*</span></label>                                                                 
                                                                    <div class="form-control">
                                                                    
                                                                        <div class=" form-check-inline">
                                                                            <input class="form-check-input" type="radio" name="identified_the_department" id="department_yes" value="1" required>
                                                                            <label class="form-check-label mb-0" for="inlineCheckbox1">District</label>
                                                                        </div>
                                                                        <div class=" form-check-inline">
                                                                            <input class="form-check-input" type="radio" name="identified_the_department" id="department_no" value="2" required>
                                                                            <label class="form-check-label mb-0" for="inlineCheckbox2">Tehsil</label>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                @error('district_name')
                                                                <div class="text-danger">{{ $message }}</div>
                                                                @enderror

                                                            </div> 
                                                                <div class="col-md-4" id="district_name_selected"  style="display: none;">
                                                                <div class="form-group mb-3">
                                                                    <label class="placeholder">District Name <span class="text-danger">*</span></label>
                                                                    <select name="district_name" id="district_name" class="form-control form-select" required>                                                                        
                                                                    @foreach($districts as $key=>$district)
                                                                    <option {{$district->id == 23 ? 'selected' : ''}} value="{{ $district->id }}" data-badge="">{{$district->city}}</option>
                                                                    @endforeach                                                                    
                                                                     </select>
                                                                </div>
                                                                @error('district_name')
                                                                <div class="text-danger">{{ $message }}</div>
                                                                @enderror

                                                            </div>
                                                            <div class="col-md-4" id="tehsil_name_selected"  style="display: none;">
                                                                <div class="form-group mb-3">
                                                                    <label class="placeholder">Tehsil Name <span class="text-danger">*</span></label>
                                                                    <select name="tehsil_name" id="tehsil_name" class="form-control form-select" required>
                                                                        <option selected="" disabled="" value="">Select Tehsil</option>
                                                                        @foreach($tehsils as $key=>$tehsil)
                                                                        <option {{$tehsil->id == 561 ? 'selected' : ''}} value="{{ $tehsil->id }}" data-badge="">{{$tehsil->Tehsil_Name}}</option>
                                                                        @endforeach
                                                                    </select>
                                                                </div>
                                                                @error('tehsil_name')
                                                                <div class="text-danger">{{ $message }}</div>
                                                                @enderror

                                                            </div>
                                                            <?php } ?>

                                                            <div class="col-md-4">
                                                                <div class="form-group mb-3">
                                                                    <label class="placeholder">Opening Balance of Financial Year <span class="text-danger">*</span></label>
                                                                    <input type="text"oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1').replace(/(\.\d{2}).+/g, '$1');" id="opening_balance_of_financial" name="opening_balance_of_financial" class="form-control" required>
                                                                </div>
                                                                @error('opening_balance_of_financial')
                                                                <div class="text-danger">{{ $message }}</div>
                                                                @enderror
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="form-group mb-3">
                                                                    <label class="placeholder">Amount Received in Current Month <span class="text-danger">*</span></label>
                                                                    <input type="text" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1').replace(/(\.\d{2}).+/g, '$1');" id="amount_received" name="amount_received" class="form-control" required>
                                                                </div>
                                                                @error('amount_received')
                                                                <div class="text-danger">{{ $message }}</div>
                                                                @enderror
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="form-group mb-3">
                                                                    <label class="placeholder">Amount Spent in Current Month <span class="text-danger">*</span></label>
                                                                    <input type="text" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1').replace(/(\.\d{2}).+/g, '$1');" id="amount_spent" name="amount_spent" class="form-control" required>
                                                                </div>
                                                                @error('amount_spent')
                                                                <div class="text-danger">{{ $message }}</div>
                                                                @enderror
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="form-group mb-3">
                                                                    <label class="placeholder">Total Balance Deposited Till Current Month <span class="text-danger">*</span></label>
                                                                    <input type="text" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1').replace(/(\.\d{2}).+/g, '$1');" id="total_balance_deposited_current_month" name="total_balance_deposited_current_month" class="form-control" required>
                                                                </div>
                                                                @error('total_balance_deposited_current_month')
                                                                <div class="text-danger">{{ $message }}</div>
                                                                @enderror
                                                            </div>

                                                            <div class="col-md-4">
                                                                <div class="form-group mb-3">
                                                                    <label class="placeholder">Total Amount Received Till Current Month <span class="text-danger">*</span></label>
                                                                    <input type="text"oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1').replace(/(\.\d{2}).+/g, '$1');" id="total_amount_received_current_month" name="total_amount_received_current_month" class="form-control" required>
                                                                </div>
                                                                @error('total_amount_received_current_month')
                                                                <div class="text-danger">{{ $message }}</div>
                                                                @enderror
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="form-group mb-3">
                                                                    <label class="placeholder">Total Amount Received Till The Same Month Last Year<span class="text-danger">*</span></label>
                                                                    <input type="text" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1').replace(/(\.\d{2}).+/g, '$1');"  id="total_amount_received_lastyear" name="total_amount_received_lastyear" class="form-control" required>
                                                                </div>
                                                                @error('total_amount_received_lastyear')
                                                                <div class="text-danger">{{ $message }}</div>
                                                                @enderror
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="form-group mb-3">
                                                                    <label class="placeholder">Increase <span class="text-danger">*</span></label>
                                                                    <input type="text" id="increase" pattern="^[A-Za-z -]+$" name="increase" class="form-control" required>
                                                                </div>
                                                                @error('increase')
                                                                <div class="text-danger">{{ $message }}</div>
                                                                @enderror
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="form-group mb-3">
                                                                    <label class="placeholder">Decrease <span class="text-danger">*</span></label>
                                                                    <input type="text" id="decrease" pattern="^[A-Za-z -]+$"  name="decrease" class="form-control" required>
                                                                </div>
                                                                @error('decrease')
                                                                <div class="text-danger">{{ $message }}</div>
                                                                @enderror
                                                            </div>
                                                        </div>
                                                        <div class="bhoechie-footer">
                                                            <div class="row justify-content-center">
                                                                <!-- <div class="col-md-2 d-grid">
                                                                    <button type="reset" class="btn btn-outline-info rounded-pill">Back</button>
                                                                </div> -->
                                                                <div class="col-md-2 d-grid">
                                                                    <button id="reset" type="reset" class="btn btn-outline-info rounded-pill">Reset</button>
                                                                </div>
                                                                <div class="col-md-2 d-grid">
                                                                    <button type="submit" class="btn btn-outline-danger rounded-pill">Save</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <input type="hidden" name="division_id" id="division_id" value="{{!empty($division_id) ? $division_id : 'null' }}">

                                          
                                            </fieldset>
													  </form>
                                        </div>

                                        <div class="col-12">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="table-responsive" id="prodiv">
                                                        <table style="width: 100%;" class="dn">
                                                            <tr>
                                                                <td align="center" style="position: relative; border: 0; padding-bottom: 5px;">
                                                                    <div style="border-bottom: 0px solid #000; padding-bottom: 2vw;">
                                                                        <!-- <img src="{{ url('/public/onlineAdmission') }}/images/logo.png" style="position: absolute; width: 70px; top: 5px; left: 0;"/> -->
                                                                        <!-- <img src="images/logo.png" style="position: absolute; width: 70px; top: 5px; left: 0;"/> -->
                                                                        <div style="font-size: 18px; font-weight: bold;">
                                                                            <!-- Department of Sports -->
                                                                            Khel Sathi Portal
                                                                        </div>
                                                                        <div style="font-size: 14px; font-weight: bold;">
                                                                            Government of Uttar Pradesh
                                                                        </div>
                                                                        <div style="font-size: 18px; font-weight: bold;">
                                                                            Sport College online application form
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    <table  class="table table-bordred table-hover bg-white datatable mb-3" id="dataTable">
                                                            <thead>
                                                                <tr>
                                                                    <th>S.No.</th>
                                                                    <?php if($admin_id ==10 ){ ?>
                                                                    <th>Division Name</th>
                                                                    <th>Opening Balance of Financial Year</th>
                                                                    <th>Amount Received in Current Month</th>
                                                                    <th>Amount Spent in Current Month</th>
                                                                    <th>Total Balance Deposited Till Current Month</th>
                                                                    <th>Total Amount Received Till Current Month</th>
                                                                    <th>Total Amount Received Till The Same Month Last Year</th>
                                                                    <th>Increase</th>
                                                                    <th>Decrease</th>
                                                                    <?php } ?>   
                                                                    <?php if($admin_id == 9 ){ ?>                                                                 
                                                                    <th>District Name</th>
                                                                    <th>Tehsil Name</th>                                                                   
                                                                    <th>Opening Balance of Financial Year</th>
                                                                    <th>Amount Received in Current Month</th>
                                                                    <th>Amount Spent in Current Month</th>
                                                                    <th>Total Balance Deposited Till Current Month</th>
                                                                    <th>Total Amount Received Till Current Month</th>
                                                                    <th>Total Amount Received Till The Same Month Last Year</th>
                                                                    <th>Increase</th>
                                                                    <th>Decrease</th>
                                                                    <?php } ?>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                            @foreach($monthlyInformation as $key=>$item)
                                                                <tr>
                                                                    <td>{{$key+1}}</td>
                                                                    <?php 
                                                                    //2 tehsil name
                                                                    if($item->status == 0){ ?>
                                                                    <td>{{!empty(divisionName($item->division_id)) ? divisionName($item->division_id) : '-' }}</td>
                                                                    <?php } ?>
                                                                    <?php 
                                                                    //1 District
                                                                    if($item->status == 1){ ?>
                                                                                                                             
                                                                    <td>{{!empty(districtName($item->district_id)) ? districtName($item->district_id) : '-' }} </td> 
                                                                    <td>-</td>
                                                                    <?php } ?>
                                                                    <?php 
                                                                    //2 tehsil name
                                                                    if($item->status == 2){ ?>
                                                                    <td>-</td>
                                                                    <td>{{!empty(tehsiltName($item->tehsil_id)) ? tehsiltName($item->tehsil_id) : '-' }}</td>
                                                                    <?php } ?>                                                                   

                                                                    <td>{{isset($item->opening_balance_of_financial) ? $item->opening_balance_of_financial : '-' }}</td> 
                                                                    <td>{{isset($item->amount_received) ? $item->amount_received : '-' }}</td> 
                                                                    <td>{{isset($item->amount_spent) ? $item->amount_spent : '-' }}</td> 
                                                                    <td>{{isset($item->total_balance_deposited_current_month) ? $item->total_balance_deposited_current_month : '-' }}</td> 
                                                                    <td>{{isset($item->total_amount_received_current_month) ? $item->total_amount_received_current_month : '-' }}</td> 
                                                                    <td>{{isset($item->total_amount_received_lastyear) ? $item->total_amount_received_lastyear : '-' }}</td> 
                                                                    
                                                                    <td>{{isset($item->increase) ? $item->increase : '-' }}</td> 
                                                                    <td>{{isset($item->decrease) ? $item->decrease : '-' }}</td> 

                                                                    
                                                                </tr>                                                             
                                                            @endforeach  
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

@endsection

@push( 'custom-scripts' )
<script>
    function PrintDoc() {
        $('#dataTable').DataTable().destroy();
        var toPrint = document.getElementById('prodiv');

        var popupWin = window.open('', '_blank', 'left=100,top=100,width=1100,height=600,tollbar=0,scrollbars=1,status=0,resizable=1');

        popupWin.document.open();

        popupWin.document.write('<html><title>::Preview::</title><head><style>body{font-family:Arial} .noprint{display: none;} table{width:100%; border-collapse:collapse;} .table tr th, .table tr td{border:1px solid #000; padding:3px 5px; font-size: 12px;} .table > thead > tr > th{background-color: #eee;}</style></head><body onload="window.print()">')

        popupWin.document.write(toPrint.innerHTML);

        popupWin.document.write('</body></html>');

        popupWin.document.close();

        $('#dataTable').DataTable();

    }
</script>
<script type="text/javascript">
    $(function() {
        var table = $('.yajra-datatable').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{ route('projectlist') }}",
            columns: [{
                data: 'DT_RowIndex',
                name: 'DT_RowIndex'
            }, {
                data: 'fullname',
                name: 'fullname'
            }, {
                data: 'project_id',
                name: 'project_id'
            }, {
                data: 'project_name',
                name: 'project_name'
            }, {
                data: 'application_date',
                name: 'application_date'
            }, {
                data: 'current_status',
                name: 'current_status',
                orderable: false,
                searchable: false
            }, {
                data: 'view',
                name: 'view',
                orderable: false,
                searchable: false
            }, ]
        });
    });
</script>

<script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
<script>
    function ExportToExcel(type, fn, dl) {
        var elt = document.getElementById('dataTable');
        var wb = XLSX.utils.table_to_book(elt, {
            sheet: "sheet1"
        });
        return dl ?
            XLSX.write(wb, {
                bookType: type,
                bookSST: true,
                type: 'base64'
            }) :
            XLSX.writeFile(wb, fn || ('Monthly Information List.' + (type || 'xlsx')));
    }
</script>
<script type="text/javascript">
    $('input[name="identified_the_department"]').click(function() {
    var identified_the_department = $(this).val();
    if (identified_the_department == 1) {
    $('#district_name_selected').show();
    $('#tehsil_name_selected').hide();
    $("#district_name").prop('required', true);
    $("#tehsil_name").prop('required', false);
    } else if (identified_the_department == 2) {
    $('#tehsil_name_selected').show();
    $('#district_name_selected').hide();
    $("#district_name").prop('required', false);
    $("#tehsil_name").prop('required', true);
    //$("#um_land_remarks").prop('required', false);
    }
    });
</script>
<script type="text/javascript">
$(document).ready(function () {
    $('#reset').click(function () {
        $('#district_name_selected').hide();

    });
});
</script>
@endpush