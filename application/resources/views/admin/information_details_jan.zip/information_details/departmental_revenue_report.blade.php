@extends( 'layouts/admin_layout' )
@section( 'content' )


<div class="row">
	<div class="col-12">
		<div class="pageheader" id="menu-margin">
			<h4 class="mb-0">
विभागीय राजस्व प्रपत्र                    </h4>
		

		</div>
	</div>
	<div class="col-12">

		<div class="table-responsive">
			<table class="table datatable mb-3" id="dataTable">
				<thead>
					<tr>
						<th colspan="31" align="center" valign="middle" nowrap="nowrap"><strong>कार्यालय का नाम</strong>
							</td>
					</tr>
					<tr>
						<th colspan="31" align="center" valign="middle" nowrap="nowrap"><strong>विभागीय राजस्व प्राप्तियों का विवरण माह का नाम - वर्ष - (धनराशि रू. में)</strong>
							</td>
					</tr>
					<tr>
						<th width="63" colspan="2" align="center" valign="middle"><strong>विवरण</strong>
							</td>
							<th width="126" colspan="4" align="center" valign="middle"><strong>प्रशिक्षण मद से आय</strong>
								</td>
								<th width="189" colspan="6" align="center" valign="middle"><strong>आरक्षण मद से आय</strong>
									</td>
									<th width="126" colspan="4" align="center" valign="middle"><strong>तरणताल मद से आय</strong>
										</td>
										<th width="126" colspan="4" align="center" valign="middle"><strong>छात्रावास मद से आय</strong>
											</td>
											<th width="329" colspan="10" align="center" valign="middle"><strong>अन्य प्राप्तियों के मद से आय</strong>
												</td>
												<th width="56" rowspan="2" align="center" valign="middle"><strong>माह में प्राप्त कुल राजस्व प्राप्तियां (कालम 6+12+16+20+24+30 का महायोग)</strong>
													</td>
					</tr>
					<tr>
						<th width="32" align="center" valign="middle"><strong>जनपद/संस्था का नाम</strong>
							</td>
							<th width="32" align="center" valign="middle"><strong>खेल का नाम</strong>
								</td>
								<th width="32" align="center" valign="middle"><strong>प्रशिक्षणार्थियों की संख्या</strong>
									</td>
									<th width="32" align="center" valign="middle"><strong>निर्धारित शुल्क</strong>
										</td>
										<th width="32" align="center" valign="middle"><strong>कुल आय</strong>
											</td>
											<th width="32" align="center" valign="middle"><strong>विभागीय प्राप्ति रसीद संख्या व दिनाँक</strong>
												</td>
												<th width="32" align="center" valign="middle"><strong>कीडांगन/ग्राउण्ड से किराया</strong>
													</td>
													<th width="32" align="center" valign="middle"><strong>बहुउद्देशीय हाल से किराया</strong>
														</td>
														<th width="32" align="center" valign="middle"><strong>कमरे बुकिंग से किराया</strong>
															</td>
															<th width="32" align="center" valign="middle"><strong>स्टेडियम के बुकिंग से किराया</strong>
																</td>
																<th width="32" align="center" valign="middle"><strong>कुल आय</strong>
																	</td>
																	<th width="32" align="center" valign="middle"><strong>विभागीय प्राप्ति रसीद संख्या व दिनाँक</strong>
																		</td>
																		<th width="32" align="center" valign="middle"><strong>प्रशिक्षणार्थियों की संख्या</strong>
																			</td>
																			<th width="32" align="center" valign="middle"><strong>निर्धारित शुल्क</strong>
																				</td>
																				<th width="32" align="center" valign="middle"><strong>कुल आय</strong>
																					</td>
																					<th width="32" align="center" valign="middle"><strong>विभागीय प्राप्ति रसीद संख्या व दिनाँक</strong>
																						</td>
																						<th width="32" align="center" valign="middle"><strong>छात्रों की संख्या</strong>
																							</td>
																							<th width="32" align="center" valign="middle"><strong>निर्धारित शुल्क</strong>
																								</td>
																								<th width="32" align="center" valign="middle"><strong>कुल आय</strong>
																									</td>
																									<th width="32" align="center" valign="middle"><strong>विभागीय प्राप्ति रसीद संख्या व दिनाँक</strong>
																										</td>
																										<th width="32" align="center" valign="middle"><strong>शौकिया खिलाड़ियों की संख्या</strong>
																											</td>
																											<th width="32" align="center" valign="middle"><strong>निर्धारित शुल्क/खिलाड़ी</strong>
																												</td>
																												<th width="32" align="center" valign="middle"><strong>कुल आय</strong>
																													</td>
																													<th width="32" align="center" valign="middle"><strong>विभागीय प्राप्ति रसीद संख्या व दिनाँक</strong>
																														</td>
																														<th width="45" align="center" valign="middle"><strong>कार/मोटर साइकिल/साइकिल स्टैण्ड से आय</strong>
																															</td>
																															<th width="32" align="center" valign="middle"><strong>निष्प्रयोज्य सामानो की नीलामी से आय</strong>
																																</td>
																																<th width="32" align="center" valign="middle"><strong>फार्मो की बिक्री से आय</strong>
																																	</td>
																																	<th width="32" align="center" valign="middle"><strong>विभाग के अन्य आय के स्रोतो से आय</strong>
																																		</td>
																																		<th width="32" align="center" valign="middle"><strong>कुल आय</strong>
																																			</td>
																																			<th width="32" align="center" valign="middle"><strong>विभागीय प्राप्ति रसीद संख्या व दिनाँक</strong>
																																				</td>
					</tr>
					<tr>
						<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>1</strong>
							</td>
							<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>3</strong>
								</td>
								<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>4</strong>
									</td>
									<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>5</strong>
										</td>
										<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>6</strong>
											</td>
											<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>7</strong>
												</td>
												<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>8</strong>
													</td>
													<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>9</strong>
														</td>
														<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>10</strong>
															</td>
															<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>11</strong>
																</td>
																<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>12</strong>
																	</td>
																	<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>13</strong>
																		</td>
																		<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>14</strong>
																			</td>
																			<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>15</strong>
																				</td>
																				<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>16</strong>
																					</td>
																					<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>17</strong>
																						</td>
																						<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>18</strong>
																							</td>
																							<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>19</strong>
																								</td>
																								<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>20</strong>
																									</td>
																									<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>21</strong>
																										</td>
																										<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>22</strong>
																											</td>
																											<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>23</strong>
																												</td>
																												<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>24</strong>
																													</td>
																													<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>25</strong>
																														</td>
																														<th width="45" align="center" valign="middle" nowrap="nowrap"><strong>26</strong>
																															</td>
																															<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>27</strong>
																																</td>
																																<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>28</strong>
																																	</td>
																																	<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>29</strong>
																																		</td>
																																		<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>30</strong>
																																			</td>
																																			<th width="32" align="center" valign="middle" nowrap="nowrap"><strong>31</strong>
																																				</td>
																																				<th width="56" align="center" valign="middle"><strong>32</strong>
																																					</td>
					</tr>

				</thead>

				<tbody>

					@foreach($departmentalInformation as $key=>$item)
					<tr>
						<?php if($item->status == 0) { ?>
						<td>{{!empty(divisionName($item->division_id)) ? divisionName($item->division_id) : '-' }}</td>
						<td>-</td>
						<td>-</td>
						<td>{{!empty($item->name_of_sport) ? $item->name_of_sport : '-' }}</td>
						<?php } ?>
						<?php if($item->status == 1) {?>
						<td>-</td>
						<td>{{!empty(districtName($item->district_id)) ? districtName($item->district_id) : '-' }}</td>
						<td>-</td>
						<td>{{!empty($item->name_of_sport) ? $item->name_of_sport : '-' }}</td>
						<?php } ?>
						<?php if($item->status == 2) {?>

						<td>-</td>
						<td>-</td>

						<td>{{!empty(tehsiltName($item->tehsil_id)) ? tehsiltName($item->tehsil_id) : '-' }}</td>
						<td>{{!empty($item->name_of_sport) ? $item->name_of_sport : '-' }}</td>

						<?php } ?>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						

					</tr>

					@endforeach

					<tr>
						<td colspan="31" nowrap="nowrap"><strong>योग</strong>
						</td>
					</tr>
					<tr>
						<td colspan="31" nowrap="nowrap">माह में राजस्व प्राप्तियां</td>
					</tr>
					<tr>
						<td colspan="31" nowrap="nowrap">गत माह की राजस्व प्राप्तियां</td>
					</tr>
					<tr>
						<td colspan="31" nowrap="nowrap">प्रगामी राजस्व प्राप्तियां</td>
					</tr>
					<tr>
						<td colspan="31" nowrap="nowrap">गत वित्तीय वर्ष में इसी माह तक राजस्व प्राप्तियां</td>
					</tr>
					<tr>
						<td colspan="31" nowrap="nowrap">राजस्व प्राप्तियां में प्रतिशत वृद्धि अथवा कमी</td>
					</tr>
					<!-- <tr>
						<td colspan="31">प्रमाणित किया जाता है उपरोक्त सभी सूचनाएं मेरी जानकारी में सही हैं तथा प्राप्त राजस्व प्राप्तियों को विभागीय लेखाशीर्षक में जमा करा दिया गया है, गलत सूचना पाये जाने पर वसूली हेतु उत्तरदायी रहेंगे।</td>
					</tr> -->

				</tbody>
			</table>



		</div>
	<!--

<table border="0"  cellspacing="0" cellpadding="0">
  <thead>
    <tr>
      <td  colspan="31" align="center" nowrap="nowrap"><strong>कार्यालय का नाम- </strong></td>
    </tr>
    <tr>
      <td  colspan="31" align="center" nowrap="nowrap"><strong>विभागीय राजस्व प्राप्तियों का विवरण माह का नाम - वर्ष - (धनराशि रू. में) </strong></td>
    </tr>
    <tr>
      <td width="63" colspan="2" align="center"><strong> विवरण </strong></td>
      <td width="126" colspan="4" align="center"><strong> प्रशिक्षण मद से आय </strong></td>
      <td width="189" colspan="6" align="center"><strong> आरक्षण मद से आय </strong></td>
      <td width="126" colspan="4" align="center"><strong> तरणताल मद से आय </strong></td>
      <td width="126" colspan="4" align="center"><strong> छात्रावास मद से आय </strong></td>
      <td width="329" colspan="10" align="center"><strong> अन्य प्राप्तियों के मद से आय </strong></td>
      <td width="56" rowspan="2" align="center"><strong> माह में प्राप्त कुल राजस्व प्राप्तियां (कालम 6+12+16+20+24+30 का महायोग) </strong></td>
    </tr>
    <tr>
      <td width="32" align="center"><strong> जनपद/संस्था का नाम </strong></td>
      <td width="32" align="center"><strong> खेल का नाम </strong></td>
      <td width="32" align="center"><strong> प्रशिक्षणार्थियों की संख्या </strong></td>
      <td width="32" align="center"><strong> निर्धारित शुल्क </strong></td>
      <td width="32" align="center"><strong> कुल आय </strong></td>
      <td width="32" align="center"><strong> विभागीय प्राप्ति रसीद संख्या व दिनाँक </strong></td>
      <td width="32" align="center"><strong> कीडांगन/ग्राउण्ड से किराया </strong></td>
      <td width="32" align="center"><strong> बहुउद्देशीय हाल से किराया </strong></td>
      <td width="32" align="center"><strong> कमरे बुकिंग से किराया </strong></td>
      <td width="32" align="center"><strong> स्टेडियम के बुकिंग से किराया </strong></td>
      <td width="32" align="center"><strong> कुल आय </strong></td>
      <td width="32" align="center"><strong> विभागीय प्राप्ति रसीद संख्या व दिनाँक </strong></td>
      <td width="32" align="center"><strong> प्रशिक्षणार्थियों की संख्या </strong></td>
      <td width="32" align="center"><strong> निर्धारित शुल्क </strong></td>
      <td width="32" align="center"><strong> कुल आय </strong></td>
      <td width="32" align="center"><strong> विभागीय प्राप्ति रसीद संख्या व दिनाँक </strong></td>
      <td width="32" align="center"><strong> छात्रों की संख्या </strong></td>
      <td width="32" align="center"><strong> निर्धारित शुल्क </strong></td>
      <td width="32" align="center"><strong> कुल आय </strong></td>
      <td width="32" align="center"><strong> विभागीय प्राप्ति रसीद संख्या व दिनाँक </strong></td>
      <td width="32" align="center"><strong> शौकिया खिलाड़ियों की संख्या </strong></td>
      <td width="32" align="center"><strong> निर्धारित शुल्क/खिलाड़ी </strong></td>
      <td width="32" align="center"><strong> कुल आय </strong></td>
      <td width="32" align="center"><strong> विभागीय प्राप्ति रसीद संख्या व दिनाँक </strong></td>
      <td width="45" align="center"><strong> कार/मोटर साइकिल/साइकिल स्टैण्ड से आय </strong></td>
      <td width="32" align="center"><strong> निष्प्रयोज्य सामानो की नीलामी से आय </strong></td>
      <td width="32" align="center"><strong> फार्मो की बिक्री से आय </strong></td>
      <td width="32" align="center"><strong> विभाग के अन्य आय के स्रोतो से आय </strong></td>
      <td width="32" align="center"><strong> कुल आय </strong></td>
      <td width="32" align="center"><strong> विभागीय प्राप्ति रसीद संख्या व दिनाँक </strong></td>
    </tr>
   
	  </thead>
	  <tbody>
	
   <tr>
      <td width="32" align="center" nowrap="nowrap"><strong>1 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>3 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>4 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>5 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>6 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>7 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>8 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>9 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>10 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>11 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>12 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>13 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>14 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>15 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>16 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>17 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>18 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>19 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>20 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>21 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>22 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>23 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>24 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>25 </strong></td>
      <td width="45" align="center" nowrap="nowrap"><strong>26 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>27 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>28 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>29 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>30 </strong></td>
      <td width="32" align="center" nowrap="nowrap"><strong>31 </strong></td>
      <td width="56" align="center"><strong>32 </strong></td>
    </tr>
    <tr>
      <td colspan="31" nowrap="nowrap" ><strong>योग</strong></td>
    </tr>
    <tr>
      <td colspan="31" nowrap="nowrap" > माह में राजस्व प्राप्तियां </td>
    </tr>
    <tr>
      <td colspan="31" nowrap="nowrap" > गत माह की राजस्व प्राप्तियां </td>
    </tr>
    <tr>
      <td colspan="31" nowrap="nowrap" > प्रगामी राजस्व प्राप्तियां </td>
    </tr>
    <tr>
      <td colspan="31" nowrap="nowrap" > गत वित्तीय वर्ष में इसी माह तक राजस्व प्राप्तियां </td>
    </tr>
    <tr>
      <td colspan="31" nowrap="nowrap" > राजस्व प्राप्तियां में प्रतिशत वृद्धि अथवा कमी </td>
    </tr>
    <tr>
      <td colspan="31" > प्रमाणित किया जाता है उपरोक्त सभी सूचनाएं मेरी जानकारी में सही हैं तथा प्राप्त राजस्व प्राप्तियों को विभागीय लेखाशीर्षक में जमा करा दिया गया है, गलत सूचना पाये जाने पर वसूली हेतु उत्तरदायी रहेंगे। </td>
    </tr>
  </tbody>
</table>
-->

</div>



	@endsection @push( 'custom-scripts' )
	<script type="text/javascript">
		$( function () {
			var table = $( '.yajra-datatable' ).DataTable( {
				processing: true,
				serverSide: true,
				ajax: "{{ route('projectlist') }}",
				columns: [ {
					data: 'DT_RowIndex',
					name: 'DT_RowIndex'
				}, {
					data: 'fullname',
					name: 'fullname'
				}, {
					data: 'project_id',
					name: 'project_id'
				}, {
					data: 'project_name',
					name: 'project_name'
				}, {
					data: 'application_date',
					name: 'application_date'
				}, {
					data: 'current_status',
					name: 'current_status',
					orderable: false,
					searchable: false
				}, {
					data: 'view',
					name: 'view',
					orderable: false,
					searchable: false
				}, ]
			} );
		} );
	</script>
	<script type="text/javascript" src="https://unpkg.com/xlsx@0.15.1/dist/xlsx.full.min.js"></script>
	<script>
		function ExportToExcel( type, fn, dl ) {
			var elt = document.getElementById( 'dataTable' );
			var wb = XLSX.utils.table_to_book( elt, {
				sheet: "sheet1"
			} );
			return dl ?
				XLSX.write( wb, {
					bookType: type,
					bookSST: true,
					type: 'base64'
				} ) :
				XLSX.writeFile( wb, fn || ( 'Sports Infrastructure List.' + ( type || 'xlsx' ) ) );
		}
	</script>
	@endpush